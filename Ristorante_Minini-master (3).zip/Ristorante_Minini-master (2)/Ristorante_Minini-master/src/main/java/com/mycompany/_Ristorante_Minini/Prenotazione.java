package com.mycompany._Ristorante_Minini;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

/**
 * Classe che rappresenta una prenotazione in un ristorante.
 */
public class Prenotazione implements Serializable {
    
    private String nome;
    private String cognome;
    private LocalDate data;
    private LocalTime ora;
    private LocalDateTime dataOra;
    private String allergie;
    private String tipologia;
    private int idPrenotazione;
    private static int nextId = 1;

    /**
     * Costruttore per la prenotazione.
     * @param nome Nome del cliente.
     * @param cognome Cognome del cliente.
     * @param data Data della prenotazione.
     * @param ora Ora della prenotazione.
     * @param allergie Eventuali allergie del cliente.
     * @param tipologia Tipologia della prenotazione (es. tavolo, evento).
     */
    public Prenotazione(String nome, String cognome, LocalDate data, LocalTime ora, String allergie, String tipologia) {
        this.nome = nome;
        this.cognome = cognome;
        this.data = data;
        this.ora = ora;
        this.dataOra = LocalDateTime.of(data, ora);
        this.allergie = allergie;
        this.tipologia = tipologia;
        this.idPrenotazione = nextId++;
    }

    /**
     * Costruttore di copia.
     * @param prenotazione La prenotazione da copiare.
     */
    public Prenotazione(Prenotazione prenotazione) {
        this(prenotazione.nome, prenotazione.cognome, prenotazione.data, prenotazione.ora,
                prenotazione.allergie, prenotazione.tipologia);
    }

    /**
     * Ottiene il nome del cliente.
     * @return Il nome del cliente.
     */
    public String getNome() {
        return nome;
    }

    /**
     * Imposta il nome del cliente.
     * @param nome Il nome del cliente.
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * Ottiene il cognome del cliente.
     * @return Il cognome del cliente.
     */
    public String getCognome() {
        return cognome;
    }

    /**
     * Imposta il cognome del cliente.
     * @param cognome Il cognome del cliente.
     */
    public void setCognome(String cognome) {
        this.cognome = cognome;
    }

    /**
     * Ottiene la data della prenotazione.
     * @return La data della prenotazione.
     */
    public LocalDate getData() {
        return data;
    }

    /**
     * Imposta la data della prenotazione.
     * @param data La data della prenotazione.
     */
    public void setData(LocalDate data) {
        this.data = data;
    }

    /**
     * Ottiene l'ora della prenotazione.
     * @return L'ora della prenotazione.
     */
    public LocalTime getOra() {
        return ora;
    }

    /**
     * Imposta l'ora della prenotazione.
     * @param ora L'ora della prenotazione.
     */
    public void setOra(LocalTime ora) {
        this.ora = ora;
    }

    /**
     * Ottiene la data e l'ora della prenotazione.
     * @return La data e l'ora della prenotazione.
     */
    public LocalDateTime getDataOra() {
        return dataOra;
    }

    /**
     * Ottiene le allergie del cliente.
     * @return Le allergie del cliente.
     */
    public String getAllergie() {
        return allergie;
    }

    /**
     * Imposta le allergie del cliente.
     * @param allergie Le allergie del cliente.
     */
    public void setAllergie(String allergie) {
        this.allergie = allergie;
    }

    /**
     * Ottiene la tipologia della prenotazione.
     * @return La tipologia della prenotazione.
     */
    public String getTipologia() {
        return tipologia;
    }

    /**
     * Imposta la tipologia della prenotazione.
     * @param tipologia La tipologia della prenotazione.
     */
    public void setTipologia(String tipologia) {
        this.tipologia = tipologia;
    }

    /**
     * Ottiene l'ID della prenotazione.
     * @return L'ID della prenotazione.
     */
    public int getIdPrenotazione() {
        return idPrenotazione;
    }

    /**
     * Imposta l'ID della prenotazione.
     * @param idPrenotazione L'ID della prenotazione.
     */
    public void setIdPrenotazione(int idPrenotazione) {
        this.idPrenotazione = idPrenotazione;
    }

    /**
     * Ottiene il prossimo ID disponibile.
     * @return Il prossimo ID disponibile.
     */
    public static int getNextId() {
        return nextId;
    }

    /**
     * Restituisce una rappresentazione in stringa della prenotazione.
     * @return Una rappresentazione in stringa della prenotazione.
     */
    @Override
    public String toString() {
        return "Prenotazione{" +
                "nome='" + nome + '\'' +
                ", cognome='" + cognome + '\'' +
                ", data=" + data +
                ", ora=" + ora +
                ", allergie='" + allergie + '\'' +
                ", tipologia='" + tipologia + '\'' +
                ", idPrenotazione=" + idPrenotazione +
                '}';
    }

    /**
     * Converte la prenotazione in formato CSV.
     * @return Una stringa in formato CSV rappresentante la prenotazione.
     */
    public String toCSV() {
        return nome + "," + cognome + "," + data + "," + ora + "," + allergie + "," + tipologia + "," + idPrenotazione;
    }

    /**
     * Crea una prenotazione da una stringa CSV.
     * @param csv La stringa CSV da cui creare la prenotazione.
     * @return Una nuova prenotazione.
     */
    public static Prenotazione fromCSV(String csv) {
        String[] fields = csv.split(",");
        return new Prenotazione(fields[0], fields[1], LocalDate.parse(fields[2]), LocalTime.parse(fields[3]), fields[4], fields[5]);
    }

    /**
     * Esporta un array di prenotazioni in un file CSV.
     * @param fileName Il nome del file in cui esportare le prenotazioni.
     * @param prenotazioni L'array di prenotazioni da esportare.
     * @param numeroPrenotazioni Il numero di prenotazioni da esportare.
     * @throws IOException Se si verifica un errore di I/O durante l'esportazione.
     */
    public static void esportaCSV(String fileName, Prenotazione[] prenotazioni, int numeroPrenotazioni) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(fileName));
        for (int i = 0; i < numeroPrenotazioni; i++) {
            Prenotazione prenotazione = prenotazioni[i];
            String dati = prenotazione.toCSV();
            writer.write(dati);
            writer.newLine();
        }
        writer.close();
    }

    /**
     * Importa un array di prenotazioni da un file CSV.
     * @param fileName Il nome del file da cui importare le prenotazioni.
     * @param prenotazioni L'array in cui memorizzare le prenotazioni importate.
     * @return Il numero di prenotazioni importate.
     * @throws IOException Se si verifica un errore di I/O durante l'importazione.
     */
    public static int importaCSV(String fileName, Prenotazione[] prenotazioni) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(fileName));
        String line;
        int numeroPrenotazioni = 0;
        while ((line = reader.readLine()) != null) {
            Prenotazione prenotazione = Prenotazione.fromCSV(line);
            prenotazioni[numeroPrenotazioni++] = prenotazione;
        }
        reader.close();
        return numeroPrenotazioni;
    }

    /**
     * Salva un array di prenotazioni in un file binario.
     * @param fileName Il nome del file in cui salvare le prenotazioni.
     * @param prenotazioni L'array di prenotazioni da salvare.
     * @param numeroPrenotazioni Il numero di prenotazioni da salvare.
     * @throws IOException Se si verifica un errore di I/O durante il salvataggio.
     */
    public static void salvaPrenotazioni(String fileName, Prenotazione[] prenotazioni, int numeroPrenotazioni) throws IOException {
        ObjectOutputStream writer = new ObjectOutputStream(new FileOutputStream(fileName));
        writer.writeInt(numeroPrenotazioni);
        for (int i = 0; i < numeroPrenotazioni; i++) {
            writer.writeObject(prenotazioni[i]);
        }
        writer.close();
    }

    /**
     * Carica un array di prenotazioni da un file binario.
     * @param fileName Il nome del file da cui caricare le prenotazioni.
     * @param prenotazioni L'array in cui memorizzare le prenotazioni caricate.
     * @return Il numero di prenotazioni caricate.
     * @throws IOException Se si verifica un errore di I/O durante il caricamento.
     * @throws ClassNotFoundException Se la classe delle prenotazioni non viene trovata.
     */
    public static int caricaPrenotazioni(String fileName, Prenotazione[] prenotazioni) throws IOException, ClassNotFoundException {
        ObjectInputStream reader = new ObjectInputStream(new FileInputStream(fileName));
        int numeroPrenotazioni = reader.readInt();
        for (int i = 0; i < numeroPrenotazioni; i++) {
            prenotazioni[i] = (Prenotazione) reader.readObject();
        }
        reader.close();
        return numeroPrenotazioni;
    }
}
