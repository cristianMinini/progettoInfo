package com.mycompany._Ristorante_Minini;

import eccezioni.EccezionePosizioneNonValida;
import eccezioni.EccezionePosizioneOccupata;
import eccezioni.EccezionePosizioneVuota;
import eccezioni.EccezioneRipianoNonValido;
import eccezioni.FileException;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Arrays;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import utilita.ConsoleInput;
import utilita.Menu;
import utilita.Ordinatore;

public class App {
    public static void main(String[] args) {
        Scanner tastiera = new Scanner(System.in);
        final int MAX_PRENOTAZIONI = 100;
        Prenotazione[] listaPrenotazioni = new Prenotazione[MAX_PRENOTAZIONI];
        int numeroPrenotazioni = 0;
        int voceScelta;
        String SereDese = "prenotazione.bin";
        String CSV = "prenotazione.csv";

        String[] vociMenu = new String[10];
        vociMenu[0] = "\t--> Esci";
        vociMenu[1] = "\t--> Visualizza tutte le prenotazioni";
        vociMenu[2] = "\t--> Aggiungi prenotazione";
        vociMenu[3] = "\t--> Visualizza prenotazione da id";
        vociMenu[4] = "\t--> Elimina prenotazione";
        vociMenu[5] = "\t--> Mostra prenotazioni presenti in ordine di tempo";
        vociMenu[6] = "\t--> Esporta le prenotazioni su file CSV";
        vociMenu[7] = "\t--> Importa le prenotazioni da file CSV";
        vociMenu[8] = "\t--> Salva dati prenotazioni";
        vociMenu[9] = "\t--> Carica dati prenotazioni";

        Menu menu = new Menu(vociMenu);

        do {
            voceScelta = menu.sceltaMenu();
            switch (voceScelta) {
                case 0:
                    System.out.println("Uscita dal programma.");
                    break;
                case 1:
                    // Visualizza tutte le prenotazioni
                    if (numeroPrenotazioni == 0) {
                        System.out.println("Nessuna prenotazione presente.");
                    } else {
                        System.out.println("Elenco delle prenotazioni:");
                        for (int i = 0; i < numeroPrenotazioni; i++) {
                            System.out.println(listaPrenotazioni[i]);
                        }
                    }
                    break;
                case 2:
                    // Aggiungi prenotazione
                    System.out.println("Inserisci nome:");
                    String nuovoNome = tastiera.nextLine();
                    System.out.println("Inserisci cognome:");
                    String nuovoCognome = tastiera.nextLine();
                    System.out.println("Inserisci data (AAAA-MM-GG):");
                    String nuovaDataStringa = tastiera.nextLine();
                    LocalDate nuovaData = LocalDate.parse(nuovaDataStringa);
                    System.out.println("Inserisci ora (HH:MM):");
                    String nuovaOraStringa = tastiera.nextLine();
                    LocalTime nuovaOra = LocalTime.parse(nuovaOraStringa);
                    System.out.println("Inserisci allergie:");
                    String nuoveAllergie = tastiera.nextLine();
                    System.out.println("Inserisci tipologia:");
                    String nuovaTipologia = tastiera.nextLine();
                    
                    Prenotazione nuovaPrenotazione = new Prenotazione(nuovoNome, nuovoCognome, nuovaData, nuovaOra,
                            nuoveAllergie, nuovaTipologia);
                    listaPrenotazioni[numeroPrenotazioni++] = nuovaPrenotazione;
                    System.out.println("Prenotazione aggiunta con successo.");
                    break;
                case 3:
                    // Visualizza prenotazione da ID
                    if (numeroPrenotazioni == 0) {
                        System.out.println("Nessuna prenotazione presente.");
                    } else {
                        System.out.println("Inserisci l'ID della prenotazione da cercare:");
                        int idDaCercare = tastiera.nextInt();
                        tastiera.nextLine();
                        boolean trovato = false;
                        for (int i = 0; i < numeroPrenotazioni; i++) {
                            if (listaPrenotazioni[i].getIdPrenotazione() == idDaCercare) {
                                System.out.println("Prenotazione trovata:");
                                System.out.println(listaPrenotazioni[i]);
                                trovato = true;
                                break;
                            }
                        }
                        if (!trovato) {
                            System.out.println("Nessuna prenotazione trovata con l'ID specificato.");
                        }
                    }
                    break;
                case 4:
                    // Elimina prenotazione
                    if (numeroPrenotazioni == 0) {
                        System.out.println("Nessuna prenotazione presente.");
                    } else {
                        System.out.println("Inserisci l'ID della prenotazione da eliminare:");
                        int idDaEliminare = tastiera.nextInt();
                        tastiera.nextLine();
                        boolean eliminato = false;
                        for (int i = 0; i < numeroPrenotazioni; i++) {
                            if (listaPrenotazioni[i].getIdPrenotazione() == idDaEliminare) {
                                for (int j = i; j < numeroPrenotazioni - 1; j++) {
                                    listaPrenotazioni[j] = listaPrenotazioni[j + 1];
                                }
                                numeroPrenotazioni--;
                                System.out.println("Prenotazione eliminata con successo.");
                                eliminato = true;
                                break;
                            }
                        }
                        if (!eliminato) {
                            System.out.println("Nessuna prenotazione trovata con l'ID specificato.");
                        }
                    }
                    break;
                case 5:
                    // Mostra prenotazioni presenti in ordine di data e ora
                    if (numeroPrenotazioni == 0) {
                        System.out.println("Nessuna prenotazione presente.");
                    } else {
                        Arrays.sort(listaPrenotazioni, 0, numeroPrenotazioni,
                                (p1, p2) -> p1.getDataOra().compareTo(p2.getDataOra()));
                        System.out.println("Elenco delle prenotazioni in ordine di data e ora:");
                        for (int i = 0; i < numeroPrenotazioni; i++) {
                            System.out.println(listaPrenotazioni[i]);
                        }
                    }
                    break;
                case 6:
                    // Esporta le prenotazioni su file CSV
                    if (numeroPrenotazioni == 0) {
                        System.out.println("Nessuna prenotazione presente.");
                    } else {
                        try {
                            Prenotazione.esportaCSV(CSV, listaPrenotazioni, numeroPrenotazioni);
                            System.out.println("Prenotazioni esportate con successo su file CSV.");
                        } catch (IOException e) {
                            System.out.println("Errore durante l'esportazione delle prenotazioni su file CSV.");
                        }
                    }
                    break;
                case 7:
                    // Importa le prenotazioni da file CSV
                    try {
                        numeroPrenotazioni = Prenotazione.importaCSV(CSV, listaPrenotazioni);
                        System.out.println("Prenotazioni importate con successo da file CSV.");
                    } catch (IOException e) {
                        System.out.println("Errore durante l'importazione delle prenotazioni da file CSV.");
                    }
                    break;
                case 8:
                    // Salva dati prenotazioni
                    if (numeroPrenotazioni == 0) {
                        System.out.println("Nessuna prenotazione presente.");
                    } else {
                        try {
                            Prenotazione.salvaPrenotazioni(SereDese, listaPrenotazioni, numeroPrenotazioni);
                            System.out.println("Dati prenotazioni salvati con successo.");
                        } catch (IOException e) {
                            System.out.println("Errore durante il salvataggio dei dati delle prenotazioni.");
                        }
                    }
                    break;
                case 9:
                    // Carica dati prenotazioni
                    try {
                        numeroPrenotazioni = Prenotazione.caricaPrenotazioni(SereDese, listaPrenotazioni);
                        System.out.println("Dati prenotazioni caricati con successo.");
                    } catch (IOException | ClassNotFoundException e) {
                        System.out.println("Errore durante il caricamento dei dati delle prenotazioni.");
                    }
                    break;
                default:
                    System.out.println("Scelta non valida");
                    break;
            }
        } while (voceScelta != 0);

        tastiera.close();
    }
}
