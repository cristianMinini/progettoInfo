/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany._Ristorante_Minini;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.time.LocalDate;
import java.time.LocalTime;
import java.io.*;

public class PrenotazioneTest {

    @Test
    public void testCreazionePrenotazioneValida() {
        Prenotazione p = new Prenotazione("Mario", "Rossi", LocalDate.of(2024, 5, 20), LocalTime.of(12, 30), "Nessuna", "Tavolo");
        assertEquals("Mario", p.getNome());
        assertEquals("Rossi", p.getCognome());
        assertEquals(LocalDate.of(2024, 5, 20), p.getData());
        assertEquals(LocalTime.of(12, 30), p.getOra());
        assertEquals("Nessuna", p.getAllergie());
        assertEquals("Tavolo", p.getTipologia());
    }

    @Test
    public void testCreazionePrenotazioneDataPassata() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Prenotazione("Luigi", "Verdi", LocalDate.of(2023, 1, 1), LocalTime.of(20, 0), "", "Evento");
        });
    }

    @Test
    public void testCreazionePrenotazioneCampiVuoti() {
        Prenotazione p = new Prenotazione("", "", LocalDate.of(2024, 12, 31), LocalTime.of(21, 0), "", "");
        assertEquals("", p.getNome());
        assertEquals("", p.getCognome());
        assertEquals(LocalDate.of(2024, 12, 31), p.getData());
        assertEquals(LocalTime.of(21, 0), p.getOra());
        assertEquals("", p.getAllergie());
        assertEquals("", p.getTipologia());
    }

    @Test
    public void testModificaNome() {
        Prenotazione p = new Prenotazione("Mario", "Rossi", LocalDate.of(2024, 5, 20), LocalTime.of(12, 30), "Nessuna", "Tavolo");
        p.setNome("Luca");
        assertEquals("Luca", p.getNome());
    }

    @Test
    public void testModificaDataOra() {
        Prenotazione p = new Prenotazione("Mario", "Rossi", LocalDate.of(2024, 5, 20), LocalTime.of(12, 30), "Nessuna", "Tavolo");
        p.setData(LocalDate.of(2024, 6, 15));
        p.setOra(LocalTime.of(19, 0));
        assertEquals(LocalDate.of(2024, 6, 15), p.getData());
        assertEquals(LocalTime.of(19, 0), p.getOra());
    }

    @Test
    public void testToCSV() {
        Prenotazione p = new Prenotazione("Mario", "Rossi", LocalDate.of(2024, 5, 20), LocalTime.of(12, 30), "Nessuna", "Tavolo");
        assertEquals("Mario,Rossi,2024-05-20,12:30,Nessuna,Tavolo,1", p.toCSV());
    }

    @Test
    public void testFromCSV() {
        String csv = "Mario,Rossi,2024-05-20,12:30,Nessuna,Tavolo,1";
        Prenotazione p = Prenotazione.fromCSV(csv);
        assertEquals("Mario", p.getNome());
        assertEquals("Rossi", p.getCognome());
        assertEquals(LocalDate.of(2024, 5, 20), p.getData());
        assertEquals(LocalTime.of(12, 30), p.getOra());
        assertEquals("Nessuna", p.getAllergie());
        assertEquals("Tavolo", p.getTipologia());
    }

    @Test
    public void testEsportazioneImportazioneCSV() throws IOException {
        Prenotazione[] prenotazioni = { new Prenotazione("Mario", "Rossi", LocalDate.of(2024, 5, 20), LocalTime.of(12, 30), "Nessuna", "Tavolo") };
        String fileName = "prenotazioni.csv";
        Prenotazione.esportaCSV(fileName, prenotazioni, 1);

        Prenotazione[] prenotazioniImportate = new Prenotazione[1];
        int numPrenotazioni = Prenotazione.importaCSV(fileName, prenotazioniImportate);
        assertEquals(1, numPrenotazioni);
        assertEquals(prenotazioni[0].toCSV(), prenotazioniImportate[0].toCSV());
    }

    @Test
    public void testSalvataggioCaricamentoOggetto() throws IOException, ClassNotFoundException {
        Prenotazione[] prenotazioni = { new Prenotazione("Mario", "Rossi", LocalDate.of(2024, 5, 20), LocalTime.of(12, 30), "Nessuna", "Tavolo") };
        String fileName = "prenotazioni.ser";
        Prenotazione.salvaPrenotazioni(fileName, prenotazioni, 1);

        Prenotazione[] prenotazioniCaricate = new Prenotazione[1];
        int numPrenotazioni = Prenotazione.caricaPrenotazioni(fileName, prenotazioniCaricate);
        assertEquals(1, numPrenotazioni);
        assertEquals(prenotazioni[0].toCSV(), prenotazioniCaricate[0].toCSV());
    }
}

